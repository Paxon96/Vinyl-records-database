package BazaDanych;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Year;
import java.util.ResourceBundle;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.util.Callback;

public class Controller implements Initializable{

    @FXML
    private TextField wykonawcaTextField;
    @FXML
    private TextField rokTextField;
    @FXML
    private TextField rodzajTextField;
    @FXML
    private TextField wytworniaTextField;
    @FXML
    private TextField krajTextField;
    @FXML
    private TextField gatunekTextField;
    @FXML
    private TextField kompozytorTextField;
    @FXML
    private Label wykonawcaLabel;
    @FXML
    private Label tytulLabel;
    @FXML
    private Label rokLabel;
    @FXML
    private Label rodzajLabel;
    @FXML
    private Label wytworniaLabel;
    @FXML
    private Label krajLabel;
    @FXML
    private Label gatunekLabel;
    @FXML
    private Label kompozytorLabel;
    @FXML
    private TextField tytulTextField;
    @FXML
    private Label reaserchAmount;
    @FXML
    private CheckBox rodzajCheckBox;
    @FXML
    private CheckBox wytworniaCheckBox;
    @FXML
    private CheckBox krajCheckBox;
    @FXML
    private CheckBox gatunekCheckBox;
    @FXML
    private CheckBox kompozytorCheckBox;
    @FXML
    private CheckBox tytulCheckBox;
    @FXML
    private CheckBox wykonawcaCheckBox;
    @FXML
    private CheckBox rokCheckBox;
    @FXML
    private TableView<ObservableList> table;
    @FXML
    private Button dbLoad;

    private ObservableList<ObservableList> data;
    private MsSqlConnection dc;
    private boolean tytulCB = false, wykonawcaCB = false, rokCB = false, rodzajCB = false, wytworniaCB = false, krajCB = false, gatunekCB = false, kompozytorCB = false;
    private int count = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
        dc = new MsSqlConnection();
        table.setPlaceholder(new Label("Wybierz dane ktore chcesz zobaczyc i nacisnij 'Load Database'"));
    }

    @FXML
    private void loadDataFromDatabase(ActionEvent event){
        String temp = " ";
        String select = "select ", from = " from Płyty as P ", where =" where P.[TYTUŁ PŁYTY] is not null ";
        boolean flag = false, isEverythingGood = true;

        table.getItems().clear();
        table.getColumns().clear();
        count = 0;

        if(tytulCB){
            String tytul = "P.[TYTUŁ PŁYTY] as Tytuł";
            temp = temp + tytul;
            flag = true;
            if(tytulTextField.getText().length() > 0){
                StringChecker toCheck = new StringChecker(tytulTextField.getText());
                if(toCheck.stringCheck()){
                    String wh = " and P.[TYTUŁ PŁYTY] like '" + tytulTextField.getText() + "%'";
                    where += wh;
                }
                else
                    isEverythingGood = false;
            }
        }

        if(wykonawcaCB){
            String wykonawca = " distinct (W.[Nazwa wykonawcy]) as Wykonawca ";
            String join = " join Wykonawcy as W on P.IDWykonawcy = W.IDWykonawców ";
            String wh = " and W.[Nazwa Wykonawcy] is not null";

            if(flag) {
                wykonawca = wykonawca.replace("distinct","");
                temp += ",";
            }

            if(wykonawcaTextField.getText().length() > 0){
                StringChecker toCheck = new StringChecker(wykonawcaTextField.getText());
                if(toCheck.stringCheck())
                    wh += " and W.[Nazwa wykonawcy] like '" + wykonawcaTextField.getText() + "%'";
                else
                    isEverythingGood = false;
            }

            temp += wykonawca;
            from +=join;
            where += wh;
            flag = true;
        }

        if(rokCB){
            String rok = " distinct (P.[ROK]) as Rok ";
            String wh = " and P.[ROK] is not null";

            if(flag){
                rok = rok.replace("distinct","");
                temp +=",";
            }

            if(rokTextField.getText().length() > 0){
                NumberChecker toCheck = new NumberChecker(rokTextField.getText());
                if(toCheck.stringCheck() && rokTextField.getText().length() <= 4 &&  Integer.parseInt(rokTextField.getText()) <= Year.now().getValue())
                    wh += " and P.[ROK] like '" + rokTextField.getText() + "%'";
                else
                    isEverythingGood = false;
            }


            temp += rok;
            where += wh;
            flag = true;
        }

        if(rodzajCB){
            String rodzaj = " distinct(P.[RODZAJ PŁYTY]) as Rodzaj ";
            String wh =" and P.[RODZAJ PŁYTY] is not null ";

            if(flag){
                rodzaj = rodzaj.replace("distinct","");
                temp += ",";
            }

            if(rodzajTextField.getText().length() > 0){
                StringChecker toCheck = new StringChecker(rodzajTextField.getText());
                if(toCheck.stringCheck() && (rodzajTextField.getText().equalsIgnoreCase("cd")|| rodzajTextField.getText().equalsIgnoreCase("winyl")) )
                    wh += " and P.[RODZAJ PŁYTY] like '" + rodzajTextField.getText() + "%'";
                else
                    isEverythingGood = false;
            }

            temp += rodzaj;
            where += wh;
            flag = true;
        }

        if(wytworniaCB){
            String wytwornia = " distinct(Wy.Wytwórnie) as Wytwórnia";
            String wh = " and Wy.Wytwórnie is not null";
            String join = " join Wytwórnie as Wy on P.IDWytwórni = Wy.IDWytwórni ";

            if(flag){
                wytwornia = wytwornia.replace("distinct","");
                temp += ",";
            }

            if(wytworniaTextField.getText().length() > 0){
                StringChecker toCheck = new StringChecker(wytworniaTextField.getText());
                if(toCheck.stringCheck())
                    wh += " and Wy.Wytwórnie like '" + wytworniaTextField.getText() + "%'";
                else
                    isEverythingGood = false;
            }

            temp += wytwornia;
            where += wh;
            from += join;
            flag = true;
        }

        if(krajCB){
            String kraj = " distinct (K.Kraje) as Kraj";
            String wh = " and K.Kraje is not null";
            String join = " join Kraje as K on P.IDKraju = K.IDKraju";

            if(flag){
                kraj = kraj.replace("distinct","");
                temp += ",";
            }

            if(krajTextField.getText().length() > 0){
                StringChecker toCheck = new StringChecker(krajTextField.getText());
                if(toCheck.stringCheck())
                    wh += " and K.Kraje like '" + krajTextField.getText() + "%'";
                else
                    isEverythingGood = false;
            }

            temp += kraj;
            where += wh;
            from += join;
            flag = true;
        }

        if(gatunekCB){
            String gatunek = " distinct (G.Gatunki) as Gatunek";
            String wh = " and G.Gatunki is not null ";
            String join = " join Gatunki as G on P.IDGatunku = G.IDGatunku";

            if(flag){
                gatunek = gatunek.replace("distinct","");
                temp += ",";
            }

            if(gatunekTextField.getText().length() > 0){
                StringChecker toCheck = new StringChecker(gatunekTextField.getText());
                if(toCheck.stringCheck())
                    wh += " and G.Gatunki like '" + gatunekTextField.getText() + "%'";
                else
                    isEverythingGood = false;
            }

            temp += gatunek;
            where += wh;
            from += join;
            flag = true;
        }

        if(kompozytorCB){
            String kompozytor = " distinct (Ko.Kompozytorzy) as Kompozytor";
            String wh = " and Ko.Kompozytorzy is not null";
            String join = " join Kompozytorzy as Ko on P.IDKOmpozytora = Ko.IDKompozytorów";

            if(flag){
                kompozytor = kompozytor.replace("distinct","");
                temp += ",";
            }

            if(kompozytorTextField.getText().length() > 0){
                StringChecker toCheck = new StringChecker(kompozytorTextField.getText());
                if(toCheck.stringCheck())
                    wh += " and Ko.Kompozytorzy like '" + kompozytorTextField.getText() + "%'";
                else
                    isEverythingGood = false;
            }

            temp += kompozytor;
            where += wh;
            from += join;
            flag = true;
        }
        String ready = select + temp + from + where;
        System.out.println(ready);

        if(flag && isEverythingGood){
            try{
                Connection connection = dc.dbConnect();
                data = FXCollections.observableArrayList();
                count = 0;

                String queryString = ready; //"select P.[TYTUŁ PŁYTY] as TP, W.[Nazwa wykonawcy] as W from Płyty as P join Wykonawcy as W on P.IDWykonawcy = W.IDWykonawców where P.[TYTUŁ PŁYTY] is not null order by IDPłyty";
                ResultSet rs = connection.createStatement().executeQuery(queryString);


                for(int i =0; i<rs.getMetaData().getColumnCount(); i++){
                    final int j = i;
                    TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                    col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>() {
                        @Override
                        public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList,String> param) {
                            return new SimpleStringProperty(param.getValue().get(j).toString());
                        }
                    });

                    col.setMinWidth(200);
                    //ol.setMaxWidth(400);
                    table.getColumns().addAll(col);
                }


                while(rs.next()) {
                    ObservableList<String> row = FXCollections.observableArrayList();
                    for(int i =1;i<=rs.getMetaData().getColumnCount(); i++)
                        row.add(rs.getString(i));
                    count ++;
                    data.add(row);
                }

                table.setItems(data);

            }catch(SQLException e){
                e.printStackTrace();
            }
        }else if(!flag)
            table.setPlaceholder(new Label("Nie wybrano żadnego kryterium względem którego chcesz wyszukać dane!"));
        else if(!isEverythingGood)
            table.setPlaceholder(new Label("Popraw dane!"));




        //tableColumn1.setCellValueFactory(new PropertyValueFactory<>("tytulPlyty"));

        reaserchAmount.textProperty().set("Wyszukano " + count + " pozycji");
    }



    public void tytulCheckBoxAction(ActionEvent actionEvent) {
        if(!tytulCB)
            tytulCB = true;
        else
            tytulCB = false;
    }

    public void wykonawcaCheckBoxAction(ActionEvent actionEvent) {
        if(!wykonawcaCB)
            wykonawcaCB = true;
        else
            wykonawcaCB = false;
    }

    public void rokCheckBoxAction(ActionEvent actionEvent) {
        if(!rokCB)
            rokCB = true;
        else
            rokCB = false;

    }

    public void rodzajCheckBoxAction(ActionEvent actionEvent) {
        if(!rodzajCB)
            rodzajCB = true;
        else
            rodzajCB = false;
    }

    public void wytworniaCheckBoxAction(ActionEvent actionEvent) {
        if(!wytworniaCB)
            wytworniaCB = true;
        else
            wytworniaCB = false;
    }

    public void krajCheckBoxAction(ActionEvent actionEvent) {
        if(!krajCB)
            krajCB = true;
        else
            krajCB = false;
    }

    public void gatunekCheckBoxAction(ActionEvent actionEvent) {
        if(!gatunekCB)
            gatunekCB = true;
        else
            gatunekCB = false;
    }

    public void kompozytorCheckBoxAction(ActionEvent actionEvent) {
        if(!kompozytorCB)
            kompozytorCB = true;
        else
            kompozytorCB = false;
    }

    public void tytulKeyTapedAction(KeyEvent keyEvent) {
            if(tytulTextField.getText().equalsIgnoreCase(""))
                tytulLabel.textProperty().set("");

            if (tytulTextField.getText().length() > 0) {
                tytulLabel.textProperty().set("");
                StringChecker checkString = new StringChecker(tytulTextField.getText());
                System.out.println(checkString.stringCheck());
                if (!checkString.stringCheck())
                    tytulLabel.textProperty().set("Błędny tytuł");
                else
                    tytulLabel.textProperty().set("");
            }
    }

    public void wykonawcaKeyTapedAction(KeyEvent keyEvent) {
        if(wykonawcaTextField.getText().equalsIgnoreCase(""))
            wykonawcaLabel.textProperty().set("");

            if (wykonawcaTextField.getText().length() > 0) {
                StringChecker checkString = new StringChecker(wykonawcaTextField.getText());
                System.out.println(checkString.stringCheck());
                if (!checkString.stringCheck())
                    wykonawcaLabel.textProperty().set("Błędny wykonawca");
                else
                    wykonawcaLabel.textProperty().set("");
            }
    }

    public void rokKeyTapedAction(KeyEvent keyEvent) {
        if(rokTextField.getText().equalsIgnoreCase(""))
            rokLabel.textProperty().set("");

            if (rokTextField.getText().length() > 0) {
                NumberChecker checkNumber = new NumberChecker(rokTextField.getText());
                System.out.println(checkNumber.stringCheck());
                if (!checkNumber.stringCheck() || rokTextField.getText().length() > 4 || Integer.parseInt(rokTextField.getText()) > Year.now().getValue())
                    rokLabel.textProperty().set("Błędny rok");
                else
                    rokLabel.textProperty().set("");
            }
    }

    public void rodzajKeyTapedAction(KeyEvent keyEvent) {
        if(rodzajTextField.getText().equalsIgnoreCase(""))
            rodzajLabel.textProperty().set("");

            if (rodzajTextField.getText().length() > 0) {
                StringChecker checkString = new StringChecker(rodzajTextField.getText());
                System.out.println(checkString.stringCheck());
                if (!checkString.stringCheck() || (!rodzajTextField.getText().equalsIgnoreCase("cd") && !rodzajTextField.getText().equalsIgnoreCase("winyl")))
                    rodzajLabel.textProperty().set("Błędny rodzaj");
                else
                    rodzajLabel.textProperty().set("");
            }
    }

    public void wytworniaKeyTapedAction(KeyEvent keyEvent) {
        if(wytworniaTextField.getText().equalsIgnoreCase(""))
            wytworniaLabel.textProperty().set("");

            if (wytworniaTextField.getText().length() > 0) {
                StringChecker checkString = new StringChecker(wytworniaTextField.getText());
                System.out.println(checkString.stringCheck());
                if (!checkString.stringCheck())
                    wytworniaLabel.textProperty().set("Błędna wytwórnia");
                else
                    wytworniaLabel.textProperty().set("");
            }
    }

    public void krajKeyTapedAction(KeyEvent keyEvent) {
        if(krajTextField.getText().equalsIgnoreCase(""))
            krajLabel.textProperty().set("");

            if (krajTextField.getText().length() > 0) {
                StringChecker checkString = new StringChecker(krajTextField.getText());
                System.out.println(checkString.stringCheck());
                if (!checkString.stringCheck())
                    krajLabel.textProperty().set("Błędny kraj");
                else
                    krajLabel.textProperty().set("");
            }
    }

    public void gatunekKeyTapedAction(KeyEvent keyEvent) {
        if(gatunekTextField.getText().equalsIgnoreCase(""))
            gatunekLabel.textProperty().set("");

        if (gatunekTextField.getText().length() > 0) {
            StringChecker checkString = new StringChecker(gatunekTextField.getText());
            System.out.println(checkString.stringCheck());
            if (!checkString.stringCheck())
                gatunekLabel.textProperty().set("Błędny gatunek");
            else
                gatunekLabel.textProperty().set("");
        }

    }

    public void kompozytorKeyTapedAction(KeyEvent keyEvent) {
        if(kompozytorTextField.getText().equalsIgnoreCase(""))
            kompozytorLabel.textProperty().set("");

            if (kompozytorTextField.getText().length() > 0) {
                StringChecker checkString = new StringChecker(kompozytorTextField.getText());
                System.out.println(checkString.stringCheck());
                if (!checkString.stringCheck())
                    kompozytorLabel.textProperty().set("Błędny kompozytor");
                else
                    kompozytorLabel.textProperty().set("");
            }
    }
}
